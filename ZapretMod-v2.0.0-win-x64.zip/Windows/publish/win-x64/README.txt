# ZapretMod для Windows

## Быстрый старт

1. **Скачайте zapret-win-bundle** с https://github.com/bol-van/zapret-win-bundle/releases
2. **Распакуйте** файлы из zapret-win-bundle в папку `bin\`:
   - `winws.exe`
   - `WinDivert64.sys`
   - `WinDivert64.dll`
3. **Запустите** `ZapretMod.exe` от имени администратора

## Использование

1. Выберите стратегию (рекомендуется "Discord + YouTube + Telegram")
2. Нажмите "▶ Запустить"
3. Проверьте работу сервисов

## Стратегии

- **Discord + YouTube + Telegram** - основная стратегия для всех сервисов
- **FAKE TLS AUTO** - автоматический fake TLS
- **SIMPLE FAKE** - простой fake метод
- **Discord Only** - только Discord
- **YouTube Only** - только YouTube
- **Telegram Only** - только Telegram

## Требования

- Windows 10/11 x64
- .NET 8 Desktop Runtime
- Права администратора

## Ссылки

- GitHub: https://github.com/WegVPN/zapret-mod-unoficcial
- zapret-win-bundle: https://github.com/bol-van/zapret-win-bundle
